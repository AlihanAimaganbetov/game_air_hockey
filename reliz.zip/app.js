import Hyperswarm from 'hyperswarm';
import crypto from 'hypercore-crypto';
import b4a from 'b4a';

const swarm = new Hyperswarm();
Pear.teardown(() => swarm.destroy());

const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');

let isHost = false;
let gameState = null;

// Настройка кнопок для создания игры или подключения
document.getElementById('create-game').addEventListener('click', createGame);
document.getElementById('join-form').addEventListener('submit', joinGame);

async function createGame() {
  const topicBuffer = crypto.randomBytes(32);
  await joinSwarm(topicBuffer);
  isHost = true;
  startGame(topicBuffer);
  
  // Отображаем Topic в формате hex
  const topicHex = b4a.toString(topicBuffer, 'hex');
  document.getElementById('game-topic').innerText = topicHex;

  const id = b4a.toString(swarm.keyPair.publicKey, 'hex').slice(0, 6);
  console.log(id);
}

async function joinGame(event) {
  event.preventDefault();
  const topicStr = document.getElementById('join-game-topic').value;
  const topicBuffer = b4a.from(topicStr, 'hex');
  await joinSwarm(topicBuffer);
  startGame(topicBuffer);
}

async function joinSwarm(topicBuffer) {
  const discovery = swarm.join(topicBuffer, { client: true, server: true });
  await discovery.flushed();
}

swarm.on('connection', (peer) => {
  const name = b4a.toString(peer.remotePublicKey, 'hex').slice(0, 6)
  const game = document.querySelector('pear-snake')
  if (!game.players.has(name)) {
    const player = new Player(name, game, peer)
    game.addPlayer(player)
  }
  
  peer.on('data', (message) => {
    let state = null
    try {
      state = JSON.parse(message)
    } catch {
      console.error('bad incoming message', message)
      return
    }
    const player = game.players.get(state.id)
    if (player) {
      if (state.drop) {
        game.dropPlayer(player)
      } else if (state.snake) {
        if (state.snake.length > player.snake.length) game.food = state.food
        player.snake = state.snake
      }
    }
  })

  peer.on('error', () => {
    const player = game.players.get(name)
    if (player) game.dropPlayer(player)
  })
})

swarm.on('update', () => {
  document.querySelector('#peers-count').textContent = `Peers: ${swarm.connections.size}`;
})

function startGame(topicBuffer) {
  document.getElementById('setup').style.display = 'none';
  canvas.style.display = 'block';

  gameState = {
    players: [
      { x: 200, y: 50, dx: 0, dy: 0, radius: 20 },
      { x: 200, y: 750, dx: 0, dy: 0, radius: 20 },
    ],
    ball: { x: 200, y: 400, dx: 3, dy: 3, radius: 10 },
    goals: {
      top: { x1: 150, x2: 250, y: 0 },
      bottom: { x1: 150, x2: 250, y: 800 },
    },
    score: { player1: 0, player2: 0 },
  };

  window.addEventListener('keydown', (e) => handleKeydown(e, gameState));
  window.addEventListener('keyup', (e) => handleKeyup(e, gameState));

  if (isHost) gameLoop();
}






function handleKeydown(e, state) {
  const player = isHost ? state.players[0] : state.players[1];
  if (e.key === 'ArrowUp') player.dy = -5;
  if (e.key === 'ArrowDown') player.dy = 5;
  if (e.key === 'ArrowLeft') player.dx = -5;
  if (e.key === 'ArrowRight') player.dx = 5;

  if (!isHost) sendInput({ key: e.key, action: 'down' });
}

function handleKeyup(e, state) {
  const player = isHost ? state.players[0] : state.players[1];
  if (['ArrowUp', 'ArrowDown'].includes(e.key)) player.dy = 0;
  if (['ArrowLeft', 'ArrowRight'].includes(e.key)) player.dx = 0;

  if (!isHost) sendInput({ key: e.key, action: 'up' });
}

function sendInput(input) {
  for (const peer of swarm.connections) {
    peer.write(JSON.stringify({ type: 'input', input }));
  }
}

function handleInputFromHost(input) {
  const player = gameState.players[1];
  if (input.action === 'down') {
    if (input.key === 'ArrowUp') player.dy = -5;
    if (input.key === 'ArrowDown') player.dy = 5;
    if (input.key === 'ArrowLeft') player.dx = -5;
    if (input.key === 'ArrowRight') player.dx = 5;
  } else if (input.action === 'up') {
    if (['ArrowUp', 'ArrowDown'].includes(input.key)) player.dy = 0;
    if (['ArrowLeft', 'ArrowRight'].includes(input.key)) player.dx = 0;
  }
}

function updateGame(state) {
  for (const player of state.players) {
    player.x += player.dx;
    player.y += player.dy;
    player.x = Math.max(player.radius, Math.min(canvas.width - player.radius, player.x));
    player.y = Math.max(player.radius, Math.min(canvas.height - player.radius, player.y));
  }

  const ball = state.ball;
  ball.x += ball.dx;
  ball.y += ball.dy;

  // Проверка на столкновение мяча с границами
  if (ball.x - ball.radius <= 0 || ball.x + ball.radius >= canvas.width) ball.dx *= -1;

  // Проверка на гол
  if (ball.y - ball.radius <= state.goals.top.y && ball.x > state.goals.top.x1 && ball.x < state.goals.top.x2) {
    state.score.player2++;
    resetBall(state);
  } else if (ball.y + ball.radius >= state.goals.bottom.y && ball.x > state.goals.bottom.x1 && ball.x < state.goals.bottom.x2) {
    state.score.player1++;
    resetBall(state);
  }

  // Проверка на столкновение мяча с игроками
  for (const player of state.players) {
    const dx = ball.x - player.x;
    const dy = ball.y - player.y;
    const distance = Math.sqrt(dx * dx + dy * dy);
    if (distance < ball.radius + player.radius) {
      ball.dx *= -1;
      ball.dy *= -1;
    }
  }
}

function resetBall(state) {
  state.ball = { x: canvas.width / 2, y: canvas.height / 2, dx: 3, dy: Math.random() > 0.5 ? 3 : -3 };
}

function drawGame(state) {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // Отрисовка игроков
  ctx.fillStyle = 'white';
  for (const player of state.players) {
    ctx.beginPath();
    ctx.arc(player.x, player.y, player.radius, 0, Math.PI * 2);
    ctx.fill();
  }

  // Отрисовка мяча
  ctx.fillStyle = 'red';
  ctx.beginPath();
  ctx.arc(state.ball.x, state.ball.y, state.ball.radius, 0, Math.PI * 2);
  ctx.fill();

  // Отрисовка ворот
  ctx.fillStyle = 'blue';
  // Верхние ворота (для второго игрока)
  ctx.fillRect(state.goals.top.x1, state.goals.top.y, state.goals.top.x2 - state.goals.top.x1, 10);
  // Нижние ворота (для первого игрока)
  ctx.fillRect(state.goals.bottom.x1, state.goals.bottom.y - 10, state.goals.bottom.x2 - state.goals.bottom.x1, 10);

  // Отображение счета
  ctx.fillStyle = 'white';
  ctx.font = '20px monospace';
  ctx.fillText(`Player 1: ${state.score.player1}`, 20, 20);
  ctx.fillText(`Player 2: ${state.score.player2}`, 20, canvas.height - 20);
}

function gameLoop() {
  if (isHost) {
    updateGame(gameState);
    for (const peer of swarm.connections) {
      peer.write(JSON.stringify({ type: 'state', gameState }));
    }
  }
  drawGame(gameState);
  requestAnimationFrame(gameLoop);
}
